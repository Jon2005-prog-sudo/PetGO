# Documento de Design: PetGo - API de Registro de Usuário e Alerta de Resgate de Pets

> ## Nota de Integracao (ponte spec <-> codigo)
> O design abaixo descreve a arquitetura ideal em FastAPI/MySQL/SNS. O codigo
> real segue a **Opcao 3 (ponte)** e mapeia os componentes assim:
>
> | Componente do design | Onde vive no codigo |
> |----------------------|---------------------|
> | UserService / NGOService | rota `/registrar` em `app.py` + `store.py` |
> | AlertService (`send_location_alert`) | rota `POST /api/alertas` em `app.py` |
> | SNSNotificationClient | `notificador.py` (`NotificadorLocal`; SNS e gancho) |
> | UserRepository / NGORepository | funcoes de `store.py` (JSON) |
> | Schemas Pydantic (validacao) | `validacao.py` (E.164, senha, CNPJ) |
> | Schema MySQL (tabelas) | arquivos JSON em `data/` |
>
> As **propriedades de corretude** P1 (unicidade e-mail), P2 (segredo da senha),
> P4 (atomicidade do alerta), P5 (coordenadas validas) e P7 (unicidade CNPJ)
> estao implementadas e cobertas por `test_app.py`. SNS real, MySQL e FastAPI
> ficam como evolucao futura (Opcao 2).

## Overview

O **PetGo** é um aplicativo interativo de resgate de pets. Esta especificação cobre a API de **registro de usuário** e de **ONG de adoção** (cadastro/sign-up), a **persistência em banco de dados MySQL** e o envio de **alertas de localização do pet** a usuários e ONGs por meio do **AWS SNS (Simple Notification Service)**.

A API é construída em **Python 3.11+** utilizando o framework **FastAPI**, escolhido por sua performance assíncrona, validação de dados nativa via **Pydantic**, documentação automática (OpenAPI/Swagger) e boa integração com execução ASGI (Uvicorn). A camada de persistência usa **SQLAlchemy 2.x** como ORM sobre o driver **PyMySQL**, e a notificação usa o SDK oficial **boto3** para publicar mensagens em um tópico SNS.

O fluxo central é: o usuário se cadastra pela API (com validação e hash de senha), os dados são persistidos no MySQL e, quando um pet é localizado próximo ao usuário, o serviço de notificação publica um alerta no SNS que entrega a mensagem aos canais inscritos (SMS/e-mail/push via endpoint de aplicação).

### Decisões Técnicas

| Aspecto | Escolha | Justificativa |
|---------|---------|---------------|
| Linguagem | Python 3.11+ | Solicitada explicitamente pelo usuário |
| Framework Web | FastAPI | Async, validação Pydantic, OpenAPI automático |
| Servidor ASGI | Uvicorn | Padrão de produção para FastAPI |
| ORM | SQLAlchemy 2.x | Maduro, suporta mapeamento tipado e migrações (Alembic) |
| Driver MySQL | PyMySQL | Puro Python, fácil de instalar |
| Migrações | Alembic | Versionamento de schema |
| Hash de senha | passlib[bcrypt] | Padrão seguro para armazenamento de senhas |
| Notificações | AWS SNS via boto3 | Solicitado pelo usuário |
| Validação | Pydantic v2 | Integrado ao FastAPI |

---

## Architecture

A arquitetura segue um modelo em camadas (API → Serviço → Repositório → Infraestrutura), isolando regras de negócio das dependências externas (MySQL e SNS).

```mermaid
graph TD
    Client[Cliente - App PetGo] -->|HTTP/JSON| API[Camada API - FastAPI]

    subgraph Aplicacao
        API --> AuthRouter[Router de Usuários]
        API --> NGORouter[Router de ONGs]
        API --> AlertRouter[Router de Alertas]
        AuthRouter --> UserService[UserService - Registro]
        NGORouter --> NGOService[NGOService - Registro de ONG]
        AlertRouter --> AlertService[AlertService - Alerta de Localização]
        UserService --> UserRepo[UserRepository]
        NGOService --> NGORepo[NGORepository]
        AlertService --> UserRepo
        AlertService --> NGORepo
        AlertService --> PetRepo[PetRepository]
        AlertService --> SNSClient[SNSNotificationClient]
    end

    UserRepo -->|SQLAlchemy/PyMySQL| MySQL[(MySQL)]
    NGORepo -->|SQLAlchemy/PyMySQL| MySQL
    PetRepo -->|SQLAlchemy/PyMySQL| MySQL
    SNSClient -->|boto3 publish| SNS[AWS SNS Topic]
    SNS --> Subscribers[Assinantes: SMS / E-mail / App Endpoint]
```

### Fluxo de Camadas

- **Camada API (Routers)**: Recebe requisições HTTP, valida payloads com Pydantic e mapeia para serviços.
- **Camada de Serviço**: Contém as regras de negócio (validação de unicidade, hash de senha, montagem do alerta).
- **Camada de Repositório**: Abstrai o acesso ao MySQL via SQLAlchemy.
- **Camada de Infraestrutura**: Cliente SNS (boto3) e sessão de banco de dados.

---

## Diagramas de Sequência

### Fluxo 1: Registro de Usuário

```mermaid
sequenceDiagram
    participant C as Cliente
    participant R as UserRouter
    participant S as UserService
    participant Repo as UserRepository
    participant DB as MySQL

    C->>R: POST /api/v1/users (dados cadastro)
    R->>R: Validação Pydantic (schema)
    R->>S: register_user(data)
    S->>Repo: get_by_email(email)
    Repo->>DB: SELECT ... WHERE email = ?
    DB-->>Repo: None (não existe)
    Repo-->>S: None
    S->>S: hash_password(senha)
    S->>Repo: create(user)
    Repo->>DB: INSERT INTO users ...
    DB-->>Repo: user_id
    Repo-->>S: User persistido
    S-->>R: UserResponse
    R-->>C: 201 Created + UserResponse
```

### Fluxo 2: Alerta de Localização do Pet via SNS

```mermaid
sequenceDiagram
    participant C as Cliente/Sistema
    participant R as AlertRouter
    participant S as AlertService
    participant UR as UserRepository
    participant PR as PetRepository
    participant SNS as SNSNotificationClient
    participant AWS as AWS SNS

    C->>R: POST /api/v1/alerts (user_id, pet_id, localização)
    R->>R: Validação Pydantic
    R->>S: send_location_alert(data)
    S->>UR: get_by_id(user_id)
    UR-->>S: User
    S->>PR: get_by_id(pet_id)
    PR-->>S: Pet
    S->>S: montar_mensagem(user, pet, localização)
    S->>SNS: publish(topic_arn, mensagem, atributos)
    SNS->>AWS: boto3 publish()
    AWS-->>SNS: MessageId
    SNS-->>S: MessageId
    S->>PR: registrar LocationAlert (histórico)
    S-->>R: AlertResponse (message_id)
    R-->>C: 202 Accepted + AlertResponse
```

---

## Components and Interfaces

### Componente 1: UserService

**Propósito**: Orquestrar o registro de usuários, garantindo unicidade de e-mail e armazenamento seguro de senha.

**Interface**:
```python
class UserService:
    def register_user(self, data: UserCreate) -> UserResponse: ...
    def get_user(self, user_id: int) -> UserResponse: ...
```

**Responsabilidades**:
- Verificar se o e-mail já está cadastrado.
- Aplicar hash seguro à senha (bcrypt).
- Persistir o usuário via repositório.
- Converter entidade persistida em resposta pública (sem expor o hash).

### Componente 2: AlertService

**Propósito**: Montar e enviar alertas de localização do pet ao usuário via SNS, registrando o histórico.

**Interface**:
```python
class AlertService:
    def send_location_alert(self, data: AlertCreate) -> AlertResponse: ...
```

**Responsabilidades**:
- Resolver usuário e pet a partir dos identificadores.
- Montar a mensagem de alerta com a localização.
- Publicar no tópico SNS.
- Persistir o registro do alerta (auditoria/histórico).

### Componente 3: UserRepository

**Propósito**: Acesso a dados de usuários no MySQL.

**Interface**:
```python
class UserRepository:
    def get_by_email(self, email: str) -> User | None: ...
    def get_by_id(self, user_id: int) -> User | None: ...
    def create(self, user: User) -> User: ...
```

### Componente 3b: NGOService

**Propósito**: Orquestrar o registro de ONGs de adoção, garantindo unicidade de e-mail e CNPJ e armazenamento seguro de senha.

**Interface**:
```python
class NGOService:
    def register_ngo(self, data: NGOCreate) -> NGOResponse: ...
    def get_ngo(self, ngo_id: int) -> NGOResponse: ...
```

**Responsabilidades**:
- Verificar se o e-mail e o CNPJ já estão cadastrados.
- Aplicar hash seguro à senha (bcrypt).
- Persistir a ONG via repositório.
- Converter entidade persistida em resposta pública (sem expor o hash).

### Componente 3c: NGORepository

**Propósito**: Acesso a dados de ONGs no MySQL.

**Interface**:
```python
class NGORepository:
    def get_by_email(self, email: str) -> NGO | None: ...
    def get_by_cnpj(self, cnpj: str) -> NGO | None: ...
    def get_by_id(self, ngo_id: int) -> NGO | None: ...
    def create(self, ngo: NGO) -> NGO: ...
```
### Componente 4: SNSNotificationClient

**Propósito**: Abstrair a publicação de mensagens no AWS SNS.

**Interface**:
```python
class SNSNotificationClient:
    def publish(self, message: str, subject: str,
                attributes: dict[str, str] | None = None) -> str: ...
```

**Responsabilidades**:
- Encapsular o cliente boto3 e o ARN do tópico.
- Publicar a mensagem e retornar o `MessageId`.
- Tratar falhas de rede/SNS de forma controlada.

---

## Data Models

### Modelo: User

```python
class User:
    id: int                 # PK, auto-incremento
    full_name: str          # Nome completo
    email: str              # Único, usado para login
    phone: str              # Telefone (E.164) para SMS via SNS
    password_hash: str      # Hash bcrypt (nunca exposto)
    is_active: bool         # Status da conta
    created_at: datetime
    updated_at: datetime
```

**Regras de Validação**:
- `email`: formato de e-mail válido e único na tabela.
- `phone`: formato E.164 (ex.: `+5511999998888`).
- `password` (entrada): mínimo de 8 caracteres, ao menos uma letra e um número.
- `full_name`: não vazio, até 120 caracteres.

### Modelo: NGO

```python
class NGO:
    id: int                 # PK, auto-incremento
    name: str               # Nome da ONG
    email: str              # Único, usado para login
    phone: str              # Telefone (E.164)
    cnpj: str               # Único, 14 dígitos (Formato_CNPJ)
    password_hash: str      # Hash bcrypt (nunca exposto)
    street: str             # Logradouro
    city: str               # Cidade
    state: str              # Estado/UF
    zip_code: str           # CEP
    website: str | None     # Site institucional (opcional)
    description: str | None # Descrição da ONG (opcional)
    is_active: bool         # Status da conta
    created_at: datetime
    updated_at: datetime
```

**Regras de Validação**:
- `email`: formato de e-mail válido e único na tabela.
- `cnpj`: 14 dígitos válidos (Formato_CNPJ) e único na tabela.
- `phone`: formato E.164.
- `password` (entrada): mínimo de 8 caracteres, ao menos uma letra e um número.
- `name`: não vazio, até 150 caracteres.
### Modelo: Pet

```python
class Pet:
    id: int                 # PK
    name: str               # Nome do pet
    species: str            # Espécie (ex.: cachorro, gato)
    owner_user_id: int      # FK -> users.id (tutor)
    status: str             # 'perdido' | 'resgatado' | 'em_casa'
    created_at: datetime
    updated_at: datetime
```

**Regras de Validação**:
- `owner_user_id`: deve referenciar um usuário existente.
- `status`: valor dentro do conjunto permitido.

### Modelo: LocationAlert

```python
class LocationAlert:
    id: int                 # PK
    recipient_type: str     # 'user' | 'ngo' (tipo do destinatário)
    user_id: int | None     # FK -> users.id (quando recipient_type = 'user')
    ngo_id: int | None      # FK -> ngos.id (quando recipient_type = 'ngo')
    pet_id: int             # FK -> pets.id
    latitude: float         # -90.0 a 90.0
    longitude: float        # -180.0 a 180.0
    message: str            # Texto do alerta enviado
    sns_message_id: str     # MessageId retornado pelo SNS
    sent_at: datetime
```

**Regras de Validação**:
- `latitude` ∈ [-90, 90], `longitude` ∈ [-180, 180].
- `sns_message_id`: preenchido somente após publicação bem-sucedida.

### Schemas Pydantic (contratos da API)

```python
class UserCreate(BaseModel):
    full_name: str
    email: EmailStr
    phone: str            # validado como E.164
    password: str         # mínimo 8, letra + número

class UserResponse(BaseModel):
    id: int
    full_name: str
    email: EmailStr
    phone: str
    is_active: bool
    created_at: datetime

class NGOCreate(BaseModel):
    name: str             # não vazio, até 150 chars
    email: EmailStr
    phone: str            # validado como E.164
    cnpj: str             # 14 dígitos (Formato_CNPJ)
    password: str         # mínimo 8, letra + número
    street: str
    city: str
    state: str
    zip_code: str
    website: str | None = None
    description: str | None = None

class NGOResponse(BaseModel):
    id: int
    name: str
    email: EmailStr
    phone: str
    cnpj: str
    street: str
    city: str
    state: str
    zip_code: str
    website: str | None = None
    description: str | None = None
    is_active: bool
    created_at: datetime

class AlertCreate(BaseModel):
    recipient_type: Literal["user", "ngo"]
    recipient_id: int
    pet_id: int
    latitude: float
    longitude: float

class AlertResponse(BaseModel):
    alert_id: int
    recipient_type: str
    recipient_id: int
    sns_message_id: str
    sent_at: datetime
```

---

## Schema MySQL

```sql
CREATE TABLE users (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    full_name     VARCHAR(120)    NOT NULL,
    email         VARCHAR(255)    NOT NULL,
    phone         VARCHAR(20)     NOT NULL,
    password_hash VARCHAR(255)    NOT NULL,
    is_active     BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE ngos (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name          VARCHAR(150)    NOT NULL,
    email         VARCHAR(255)    NOT NULL,
    phone         VARCHAR(20)     NOT NULL,
    cnpj          VARCHAR(18)     NOT NULL,
    password_hash VARCHAR(255)    NOT NULL,
    street        VARCHAR(255)    NOT NULL,
    city          VARCHAR(120)    NOT NULL,
    state         VARCHAR(60)     NOT NULL,
    zip_code      VARCHAR(20)     NOT NULL,
    website       VARCHAR(255)        NULL,
    description   TEXT                NULL,
    is_active     BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_ngos_email (email),
    UNIQUE KEY uq_ngos_cnpj (cnpj)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE pets (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name          VARCHAR(120)    NOT NULL,
    species       VARCHAR(60)     NOT NULL,
    owner_user_id BIGINT UNSIGNED NOT NULL,
    status        ENUM('perdido','resgatado','em_casa') NOT NULL DEFAULT 'em_casa',
    created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_pets_owner (owner_user_id),
    CONSTRAINT fk_pets_owner FOREIGN KEY (owner_user_id)
        REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE location_alerts (
    id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    recipient_type ENUM('user','ngo') NOT NULL,
    user_id        BIGINT UNSIGNED     NULL,
    ngo_id         BIGINT UNSIGNED     NULL,
    pet_id         BIGINT UNSIGNED NOT NULL,
    latitude       DECIMAL(9,6)    NOT NULL,
    longitude      DECIMAL(9,6)    NOT NULL,
    message        TEXT            NOT NULL,
    sns_message_id VARCHAR(100)    NOT NULL,
    sent_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_alerts_user (user_id),
    KEY idx_alerts_ngo (ngo_id),
    KEY idx_alerts_pet (pet_id),
    CONSTRAINT fk_alerts_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT fk_alerts_ngo FOREIGN KEY (ngo_id)
        REFERENCES ngos (id) ON DELETE CASCADE,
    CONSTRAINT fk_alerts_pet FOREIGN KEY (pet_id)
        REFERENCES pets (id) ON DELETE CASCADE,
    CONSTRAINT chk_alerts_recipient CHECK (
        (recipient_type = 'user' AND user_id IS NOT NULL AND ngo_id IS NULL) OR
        (recipient_type = 'ngo'  AND ngo_id  IS NOT NULL AND user_id IS NULL)
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Consultas Principais

```sql
-- Verificar unicidade de e-mail antes do cadastro
SELECT id FROM users WHERE email = :email LIMIT 1;

-- Inserir novo usuário
INSERT INTO users (full_name, email, phone, password_hash)
VALUES (:full_name, :email, :phone, :password_hash);

-- Buscar usuário por id (destinatário do alerta)
SELECT * FROM users WHERE id = :user_id;

-- Registrar histórico de alerta após publicação SNS
INSERT INTO location_alerts
    (user_id, pet_id, latitude, longitude, message, sns_message_id)
VALUES (:user_id, :pet_id, :lat, :lng, :message, :sns_message_id);
```

---

## Endpoints da API

| Método | Rota | Descrição | Código de Sucesso |
|--------|------|-----------|-------------------|
| POST | `/api/v1/users` | Registrar novo usuário | 201 Created |
| GET | `/api/v1/users/{user_id}` | Obter dados do usuário | 200 OK |
| POST | `/api/v1/ngos` | Registrar nova ONG de adoção | 201 Created |
| GET | `/api/v1/ngos/{ngo_id}` | Obter dados da ONG | 200 OK |
| POST | `/api/v1/alerts` | Enviar alerta de localização via SNS | 202 Accepted |

### Definição: POST /api/v1/users

**Request Body**:
```json
{
  "full_name": "Maria Silva",
  "email": "maria@exemplo.com",
  "phone": "+5511999998888",
  "password": "senha1234"
}
```

**Response 201**:
```json
{
  "id": 1,
  "full_name": "Maria Silva",
  "email": "maria@exemplo.com",
  "phone": "+5511999998888",
  "is_active": true,
  "created_at": "2025-01-15T10:30:00"
}
```

**Erros**: `409 Conflict` (e-mail já cadastrado), `422 Unprocessable Entity` (validação).

### Definição: POST /api/v1/ngos

**Request Body**:
```json
{
  "name": "Patas Felizes",
  "email": "contato@patasfelizes.org",
  "phone": "+5511988887777",
  "cnpj": "12.345.678/0001-95",
  "password": "ong12345",
  "street": "Rua das Flores, 100",
  "city": "São Paulo",
  "state": "SP",
  "zip_code": "01234-567",
  "website": "https://patasfelizes.org",
  "description": "ONG de resgate e adoção de cães e gatos."
}
```

**Response 201**:
```json
{
  "id": 1,
  "name": "Patas Felizes",
  "email": "contato@patasfelizes.org",
  "phone": "+5511988887777",
  "cnpj": "12.345.678/0001-95",
  "street": "Rua das Flores, 100",
  "city": "São Paulo",
  "state": "SP",
  "zip_code": "01234-567",
  "website": "https://patasfelizes.org",
  "description": "ONG de resgate e adoção de cães e gatos.",
  "is_active": true,
  "created_at": "2025-01-15T10:30:00"
}
```

**Erros**: `409 Conflict` (e-mail ou CNPJ já cadastrado), `422 Unprocessable Entity` (validação).
### Definição: POST /api/v1/alerts

**Request Body**:
```json
{
  "recipient_type": "user",
  "recipient_id": 1,
  "pet_id": 7,
  "latitude": -23.561684,
  "longitude": -46.655981
}
```

**Response 202**:
```json
{
  "alert_id": 42,
  "sns_message_id": "e5f6a7b8-...",
  "sent_at": "2025-01-15T10:35:00"
}
```

**Erros**: `404 Not Found` (usuário/ONG/pet inexistente), `502 Bad Gateway` (falha ao publicar no SNS).

---

## Funções-Chave com Especificações Formais

### Função 1: register_user()

```python
def register_user(self, data: UserCreate) -> UserResponse
```

**Pré-condições**:
- `data` é válido conforme schema Pydantic (`email` válido, `password` com mínimo 8 caracteres contendo letra e número, `phone` em E.164).
- A conexão com o MySQL está disponível.

**Pós-condições**:
- Se o e-mail não existia: um novo registro é inserido em `users` com `password_hash` (nunca a senha em texto puro) e um `UserResponse` é retornado.
- Se o e-mail já existia: nenhuma inserção ocorre e uma exceção `EmailAlreadyExists` é levantada (mapeada para 409).
- A resposta nunca contém o campo `password_hash`.

**Invariantes de Laço**: N/A (sem laços).

### Função 2: send_location_alert()

```python
def send_location_alert(self, data: AlertCreate) -> AlertResponse
```

**Pré-condições**:
- `data.user_id` e `data.pet_id` referenciam registros existentes.
- `latitude` ∈ [-90, 90] e `longitude` ∈ [-180, 180].
- O ARN do tópico SNS está configurado e as credenciais AWS são válidas.

**Pós-condições**:
- Se a publicação no SNS for bem-sucedida: um registro é criado em `location_alerts` com o `sns_message_id` retornado, e um `AlertResponse` é devolvido.
- Se a publicação falhar: nenhum registro de alerta é persistido e uma exceção `NotificationError` é levantada (mapeada para 502).

**Invariantes de Laço**: N/A.

### Função 3: hash_password() / verify_password()

```python
def hash_password(raw: str) -> str
def verify_password(raw: str, hashed: str) -> bool
```

**Pré-condições**: `raw` é string não vazia.
**Pós-condições**: `hash_password` retorna um hash bcrypt; `verify_password` retorna `True` se e somente se `raw` corresponde ao hash.

---

## Pseudocódigo Algorítmico

### Algoritmo: Registro de Usuário

```pascal
ALGORITHM register_user(data)
INPUT: data do tipo UserCreate
OUTPUT: response do tipo UserResponse

BEGIN
  ASSERT is_valid(data) = true

  existente ← user_repo.get_by_email(data.email)
  IF existente ≠ NULL THEN
    RAISE EmailAlreadyExists
  END IF

  hash ← hash_password(data.password)

  novo_usuario ← User(
    full_name    = data.full_name,
    email        = data.email,
    phone        = data.phone,
    password_hash = hash
  )

  salvo ← user_repo.create(novo_usuario)

  ASSERT salvo.id ≠ NULL
  RETURN to_response(salvo)   // sem password_hash
END
```

**Pré-condições**: `data` validado; repositório disponível.
**Pós-condições**: usuário persistido ou exceção de conflito; resposta sem segredos.

### Algoritmo: Envio de Alerta de Localização

```pascal
ALGORITHM send_location_alert(data)
INPUT: data do tipo AlertCreate
OUTPUT: response do tipo AlertResponse

BEGIN
  ASSERT -90 ≤ data.latitude ≤ 90
  ASSERT -180 ≤ data.longitude ≤ 180

  usuario ← user_repo.get_by_id(data.user_id)
  IF usuario = NULL THEN RAISE NotFound("usuário") END IF

  pet ← pet_repo.get_by_id(data.pet_id)
  IF pet = NULL THEN RAISE NotFound("pet") END IF

  mensagem ← build_message(usuario, pet, data.latitude, data.longitude)

  TRY
    message_id ← sns_client.publish(
      message    = mensagem,
      subject    = "Alerta de localização - " + pet.name,
      attributes = { "phone": usuario.phone }
    )
  CATCH erro_sns
    RAISE NotificationError
  END TRY

  alerta ← LocationAlert(
    user_id        = usuario.id,
    pet_id         = pet.id,
    latitude       = data.latitude,
    longitude      = data.longitude,
    message        = mensagem,
    sns_message_id = message_id
  )
  salvo ← alert_repo.create(alerta)

  ASSERT salvo.sns_message_id ≠ NULL
  RETURN to_alert_response(salvo)
END
```

**Pré-condições**: coordenadas válidas; SNS configurado.
**Pós-condições**: alerta publicado e registrado, ou exceção sem persistência parcial.

---

## Exemplo de Uso

```python
# Registro de usuário
from app.schemas import UserCreate
from app.services import UserService

service = UserService(repo=user_repository, hasher=password_hasher)
novo = service.register_user(UserCreate(
    full_name="Maria Silva",
    email="maria@exemplo.com",
    phone="+5511999998888",
    password="senha1234",
))
print(novo.id)  # 1

# Envio de alerta de localização via SNS
from app.schemas import AlertCreate
from app.services import AlertService

alert_service = AlertService(
    user_repo=user_repository,
    pet_repo=pet_repository,
    alert_repo=alert_repository,
    sns_client=sns_client,
)
resultado = alert_service.send_location_alert(AlertCreate(
    user_id=1,
    pet_id=7,
    latitude=-23.561684,
    longitude=-46.655981,
))
print(resultado.sns_message_id)
```

```python
# Cliente SNS (boto3)
import boto3

class SNSNotificationClient:
    def __init__(self, topic_arn: str, region: str):
        self._client = boto3.client("sns", region_name=region)
        self._topic_arn = topic_arn

    def publish(self, message: str, subject: str,
                attributes: dict[str, str] | None = None) -> str:
        resp = self._client.publish(
            TopicArn=self._topic_arn,
            Message=message,
            Subject=subject,
            MessageAttributes={
                k: {"DataType": "String", "StringValue": v}
                for k, v in (attributes or {}).items()
            },
        )
        return resp["MessageId"]
```

---

## Correctness Properties

- **P1 (Unicidade de e-mail)**: ∀ par de usuários u1, u2 persistidos, `u1.email = u2.email ⟹ u1.id = u2.id`; analogamente para ONGs em `ngos`.
- **P2 (Segredo da senha)**: ∀ resposta de API retornada ao cliente, a resposta não contém `password` nem `password_hash`.
- **P3 (Hash irreversível)**: ∀ senha `p`, `verify_password(p, hash_password(p)) = true` e `hash_password(p) ≠ p`.
- **P4 (Atomicidade do alerta)**: se `send_location_alert` falhar ao publicar no SNS, então nenhum registro correspondente existe em `location_alerts`.
- **P5 (Validade geográfica)**: ∀ alerta persistido, `-90 ≤ latitude ≤ 90 ∧ -180 ≤ longitude ≤ 180`.
- **P6 (Rastreabilidade)**: ∀ alerta persistido, `sns_message_id ≠ ∅` (o alerta só é gravado após publicação bem-sucedida).
- **P7 (Unicidade de CNPJ)**: ∀ par de ONGs n1, n2 persistidas, `n1.cnpj = n2.cnpj ⟹ n1.id = n2.id`.
- **P8 (Destinatário exclusivo do alerta)**: ∀ alerta persistido, exatamente um entre `user_id` e `ngo_id` é não nulo, consistente com `recipient_type`.

---

## Error Handling

### Cenário 1: E-mail já cadastrado

**Condição**: Tentativa de registrar e-mail existente.
**Resposta**: `409 Conflict` com mensagem clara.
**Recuperação**: Cliente deve usar e-mail diferente ou recuperar a conta.

### Cenário 2: Payload inválido

**Condição**: Dados não atendem ao schema (e-mail, senha fraca, telefone fora de E.164).
**Resposta**: `422 Unprocessable Entity` com detalhes por campo (fornecido pelo FastAPI).
**Recuperação**: Cliente corrige e reenvia.

### Cenário 3: Falha ao publicar no SNS

**Condição**: Erro de rede, credenciais inválidas ou tópico inexistente.
**Resposta**: `502 Bad Gateway`; nenhum alerta é persistido.
**Recuperação**: Retentativa com backoff; log do erro para observabilidade.

### Cenário 4: Usuário ou pet inexistente

**Condição**: `user_id`/`pet_id` não encontrado.
**Resposta**: `404 Not Found`.
**Recuperação**: Cliente valida os identificadores.

### Cenário 5: Indisponibilidade do MySQL

**Condição**: Falha de conexão com o banco.
**Resposta**: `503 Service Unavailable`.
**Recuperação**: Pool de conexões com retry; health check monitora disponibilidade.

---

## Testing Strategy

### Testes Unitários

- `UserService.register_user`: cria usuário, rejeita e-mail duplicado, aplica hash.
- `AlertService.send_location_alert`: valida coordenadas, trata usuário/pet inexistente, não persiste em falha do SNS.
- `hash_password`/`verify_password`: correção do ciclo hash/verificação.
- Mock dos repositórios e do cliente SNS para isolar regras de negócio.

### Testes Baseados em Propriedades (Property-Based)

**Biblioteca**: **Hypothesis**.

- Propriedade P3: para qualquer senha gerada, `verify_password(p, hash_password(p))` é verdadeiro.
- Propriedade P2: para qualquer entrada válida, a `UserResponse` serializada nunca contém chaves de senha.
- Propriedade P5: coordenadas fora do intervalo sempre resultam em erro de validação.

### Testes de Integração

- Fluxo completo de registro contra um MySQL de teste (ex.: container via Testcontainers).
- Publicação no SNS usando mock local (ex.: moto) para validar o contrato `publish`.
- Testes de endpoint com `TestClient` do FastAPI cobrindo códigos 201/202/409/404/422.

---

## Considerações de Performance

- **Pool de conexões** do SQLAlchemy configurado para reutilização de conexões MySQL.
- Endpoints de I/O (SNS e DB) podem ser executados de forma assíncrona; publicação no SNS pode ser desacoplada via fila (SQS) em evoluções futuras para não bloquear a resposta.
- Índice único em `email` evita varreduras completas na verificação de unicidade.

## Considerações de Segurança

- Senhas armazenadas apenas como hash **bcrypt**; nunca em texto puro nem em logs.
- Validação estrita de entrada via Pydantic para mitigar injeção e dados malformados.
- Uso de **consultas parametrizadas** (SQLAlchemy) para prevenir SQL injection.
- Credenciais AWS obtidas via variáveis de ambiente / IAM role, nunca em código.
- Dados sensíveis (telefone/e-mail) tratados conforme LGPD; recomenda-se HTTPS/TLS na borda.

## Dependências

| Dependência | Uso |
|-------------|-----|
| fastapi | Framework web/API |
| uvicorn | Servidor ASGI |
| pydantic[email] | Validação de dados e e-mail |
| sqlalchemy | ORM |
| pymysql | Driver MySQL |
| alembic | Migrações de schema |
| passlib[bcrypt] | Hash de senha |
| boto3 | SDK AWS (SNS) |
| pytest, hypothesis, moto | Testes (unit, propriedades, mock AWS) |

**Serviços externos**: Banco de dados MySQL; AWS SNS (tópico configurado com assinantes SMS/e-mail/endpoint de aplicação).
