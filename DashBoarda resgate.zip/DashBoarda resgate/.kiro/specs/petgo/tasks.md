# Implementation Plan: PetGo - API de Registro de Usuário e Alerta de Resgate de Pets

> ## Nota de Integracao (ponte spec <-> codigo)
> O plano abaixo e do PetGo ideal (FastAPI/MySQL/SNS). Na **Opcao 3 (ponte)**,
> entregamos os mesmos CONCEITOS sobre o stack real (Flask/JSON/web). Mapa do
> que ja esta pronto no codigo da ponte:
>
> | Conceito das tasks | Status na ponte | Onde |
> |--------------------|-----------------|------|
> | Registro de usuario com hash | FEITO | `app.py` `/registrar`, `store.criar_usuario` |
> | Registro de ONG (CNPJ, endereco) | FEITO | `app.py` `/registrar`, `store.criar_ong` |
> | Unicidade e-mail / CNPJ | FEITO | `store.py` |
> | Validacao senha / E.164 / CNPJ | FEITO | `validacao.py` |
> | Alerta de localizacao + atomicidade | FEITO | `app.py` `/api/alertas`, `notificador.py` |
> | Testes (unidade + fluxo) | FEITO | `test_app.py` (todos passam) |
> | FastAPI / Pydantic / MySQL / Alembic / SNS real | PENDENTE (Opcao 2) | - |
>
> As caixas `[x]/[ ]` originais abaixo referem-se ao PetGo IDEAL e foram
> mantidas como estao: no caminho da ponte elas nao se aplicam diretamente,
> pois a implementacao equivalente vive nos arquivos citados na tabela acima.

## Overview

Este plano converte o design aprovado em uma sequência incremental de tarefas de codificação em **Python 3.11+** usando **FastAPI, SQLAlchemy 2.x + PyMySQL, Alembic, passlib[bcrypt] e boto3**, com testes em **pytest + Hypothesis + moto**.

A ordem segue a arquitetura em camadas: scaffolding e configuração → modelos e schema (Alembic) → schemas Pydantic → segurança (hash de senha) → repositórios → cliente SNS → serviços (UserService, AlertService) → tratamento de erros → routers/endpoints → wiring do app → testes de integração. Cada tarefa constrói sobre a anterior, sem etapas "big-bang", e finaliza com a integração de tudo no ponto de entrada da aplicação.

Convenções:
- Sub-tarefas de teste são marcadas com `*` (opcionais). Tarefas de topo nunca são opcionais.
- Cada tarefa referencia os requisitos (`_Requisitos: X.Y_`) e, quando aplicável, as propriedades de corretude (P1-P6) do design.

## Tasks

- [x] 1. Estruturar o projeto e as dependências
  - Criar a estrutura de pacotes `app/` (ex.: `app/__init__.py`, `app/api/`, `app/services/`, `app/repositories/`, `app/models/`, `app/schemas/`, `app/core/`, `app/infra/`) e o diretório `tests/`
  - Criar `pyproject.toml`/`requirements.txt` fixando as dependências: `fastapi`, `uvicorn`, `pydantic[email]`, `sqlalchemy`, `pymysql`, `alembic`, `passlib[bcrypt]`, `boto3`, `pytest`, `hypothesis`, `moto`
  - Configurar `pytest.ini`/seção de testes e a base de configuração do Alembic (`alembic.ini`, `alembic/env.py`)
  - _Requisitos: 1.1, 2.1, 3.1_

- [x] 2. Implementar configuração e variáveis de ambiente
  - [x] 2.1 Criar o módulo de configuração (`app/core/config.py`)
    - Definir `Settings` (Pydantic Settings) lendo de variáveis de ambiente: URL do MySQL, `SNS_TOPIC_ARN`, `AWS_REGION`, credenciais AWS obtidas do ambiente/IAM role
    - Garantir que credenciais AWS nunca sejam embutidas em código
    - _Requisitos: 6.5_
  - [ ]* 2.2 Escrever testes unitários para a configuração
    - Validar leitura de variáveis de ambiente e valores padrão
    - _Requisitos: 6.5_

- [ ] 3. Implementar a camada de banco de dados (sessão e base ORM)
  - [ ] 3.1 Criar o engine, a `SessionLocal` e a `Base` declarativa (`app/infra/database.py`)
    - Configurar engine SQLAlchemy 2.x com PyMySQL e pool de conexões reutilizável
    - Expor dependência de sessão para injeção no FastAPI
    - _Requisitos: 2.1, 5.4, 6.4_

- [ ] 4. Implementar os modelos ORM e o schema MySQL
  - [ ] 4.1 Definir os modelos `User`, `NGO`, `Pet` e `LocationAlert` (`app/models/`)
    - Mapear colunas conforme o schema do design, com `UNIQUE` em `users.email`, `UNIQUE` em `ngos.email` e `ngos.cnpj`, e FKs de `pets.owner_user_id`, `location_alerts.pet_id`, `location_alerts.user_id` e `location_alerts.ngo_id`
    - Modelar o destinatário polimórfico do alerta (`recipient_type` + `user_id`/`ngo_id`) conforme o design
    - _Requisitos: 2.2, 2.5, 1.2, 2.7_
  - [ ] 4.2 Criar a migração inicial do Alembic
    - Gerar/validar a migração que cria `users`, `ngos`, `pets` e `location_alerts` com índices e restrições do design (incluindo `UNIQUE` de `ngos.email`/`ngos.cnpj` e o CHECK de destinatário exclusivo do alerta)
    - _Requisitos: 2.1, 2.2, 2.5, 2.6, 2.7_
  - [ ]* 4.3 Escrever testes de integração do schema (SQLite/MySQL de teste)
    - Verificar unicidade de `email` (P1) e que FKs referenciam registros existentes
    - **Property 1 (P1): Unicidade de e-mail**
    - **Validates: Requisitos 2.2, 2.5**

- [ ] 5. Implementar os schemas Pydantic (contratos da API) e validação de entrada
  - [ ] 5.1 Definir `UserCreate` e `UserResponse` (`app/schemas/user.py`)
    - Validar `email` (EmailStr), `phone` em E.164, `password` (mínimo 8, ao menos uma letra e um número), `full_name` (não vazio, até 120 chars)
    - Garantir que `UserResponse` não expõe `password` nem `password_hash`
    - _Requisitos: 4.1, 4.2, 4.3, 4.4, 6.2_
  - [ ] 5.2 Definir `AlertCreate` e `AlertResponse` (`app/schemas/alert.py`)
    - Validar `latitude` ∈ [-90, 90] e `longitude` ∈ [-180, 180]
    - Incluir `recipient_type` (`user`|`ngo`) e `recipient_id` em `AlertCreate`; refletir ambos em `AlertResponse`
    - _Requisitos: 4.5, 3.1_
  - [ ] 5.6 Definir `NGOCreate` e `NGOResponse` (`app/schemas/ngo.py`)
    - Validar `email` (EmailStr), `phone` em E.164, `cnpj` em Formato_CNPJ (14 dígitos), `password` (mínimo 8, letra + número), `name` (não vazio, até 150 chars) e campos de endereço
    - Garantir que `NGOResponse` não expõe `password` nem `password_hash`
    - _Requisitos: 7.1, 7.3, 4.7, 6.2_
  - [ ]* 5.3 Escrever teste de propriedade para validação de coordenadas
    - **Property 5 (P5): Validade geográfica** — coordenadas fora do intervalo sempre resultam em erro de validação
    - **Validates: Requisitos 4.5**
  - [ ]* 5.4 Escrever teste de propriedade para segredo da senha na resposta
    - **Property 2 (P2): Segredo da senha** — `UserResponse` serializada nunca contém `password`/`password_hash`
    - **Validates: Requisitos 6.2**
  - [ ]* 5.5 Escrever testes unitários de validação de campos
    - Cobrir e-mail inválido, senha fraca, telefone fora de E.164, `full_name` vazio/excedente
    - _Requisitos: 4.1, 4.2, 4.3, 4.4, 4.6_

- [ ] 6. Implementar segurança de senhas (hash e verificação)
  - [ ] 6.1 Criar `hash_password` e `verify_password` com passlib[bcrypt] (`app/core/security.py`)
    - `hash_password` retorna hash bcrypt; `verify_password` retorna `True` somente quando a senha corresponde ao hash
    - _Requisitos: 6.1, 6.6_
  - [ ]* 6.2 Escrever teste de propriedade do ciclo hash/verificação
    - **Property 3 (P3): Hash irreversível** — ∀ senha `p`, `verify_password(p, hash_password(p))` é verdadeiro e `hash_password(p) ≠ p`
    - **Validates: Requisitos 6.1, 6.6**

- [ ] 7. Implementar a camada de repositórios
  - [ ] 7.1 Implementar `UserRepository` (`app/repositories/user_repository.py`)
    - Métodos `get_by_email`, `get_by_id` e `create` usando consultas parametrizadas do SQLAlchemy; `create` retorna o id gerado
    - _Requisitos: 2.1, 2.3, 6.4_
  - [ ] 7.4 Implementar `NGORepository` (`app/repositories/ngo_repository.py`)
    - Métodos `get_by_email`, `get_by_cnpj`, `get_by_id` e `create` com consultas parametrizadas; `create` retorna o id gerado
    - _Requisitos: 2.6, 2.7, 6.4_
  - [ ] 7.2 Implementar `PetRepository` e `AlertRepository` (`app/repositories/`)
    - `PetRepository.get_by_id`; `AlertRepository.create` inserindo `user_id`, `pet_id`, `latitude`, `longitude`, `message`, `sns_message_id`
    - _Requisitos: 2.4, 2.5, 6.4_
  - [ ]* 7.3 Escrever testes unitários/integração dos repositórios
    - Verificar inserção/consulta e uso de parâmetros ligados (sem concatenação de SQL)
    - _Requisitos: 2.1, 2.3, 2.4, 6.4_

- [ ] 8. Implementar o cliente de notificação SNS
  - [ ] 8.1 Implementar `SNSNotificationClient` com boto3 (`app/infra/sns_client.py`)
    - Encapsular o `topic_arn`/região, método `publish(message, subject, attributes)` retornando o `MessageId`; obter credenciais do ambiente/IAM role
    - _Requisitos: 3.2, 6.5_
  - [ ]* 8.2 Escrever testes do cliente SNS com moto
    - Validar o contrato `publish` e o retorno do `MessageId` usando o mock do SNS
    - _Requisitos: 3.2_

- [ ] 9. Definir exceções de domínio e tratamento de erros
  - [ ] 9.1 Criar exceções de domínio (`app/core/exceptions.py`)
    - `EmailAlreadyExists`, `NotFound`, `NotificationError` (e, se necessário, erro de indisponibilidade de banco)
    - _Requisitos: 5.1, 5.2, 5.3, 5.4_
  - [ ] 9.2 Registrar exception handlers do FastAPI (`app/api/error_handlers.py`)
    - Mapear exceções para HTTP 409, 404, 502, 503 e 422; incluir detalhes por campo na validação; logar erros de infraestrutura sem vazar senha/hash e sem derrubar o serviço
    - _Requisitos: 4.6, 5.1, 5.2, 5.3, 5.4, 5.5, 6.3_
  - [ ]* 9.3 Escrever testes unitários dos handlers de erro
    - Verificar os mapeamentos de status e o formato das respostas de erro
    - _Requisitos: 5.1, 5.2, 5.3, 5.4, 4.6_

- [ ] 10. Implementar os serviços de registro (UserService e NGOService)
  - [ ] 10.1 Implementar `UserService.register_user` e `get_user` (`app/services/user_service.py`)
    - Verificar unicidade de e-mail (lança `EmailAlreadyExists`), aplicar hash de senha, persistir via `UserRepository`, mapear para `UserResponse` com `is_active=True`, sem expor hash
    - _Requisitos: 1.1, 1.2, 1.3, 1.4, 5.1, 6.1, 6.2_
  - [ ]* 10.2 Escrever testes unitários do UserService
    - Criar usuário, rejeitar e-mail duplicado (409), garantir hash aplicado e ausência de hash na resposta (mocks de repositório)
    - _Requisitos: 1.1, 1.2, 5.1, 6.1, 6.2_
  - [ ] 10.3 Implementar `NGOService.register_ngo` e `get_ngo` (`app/services/ngo_service.py`)
    - Verificar unicidade de e-mail e CNPJ (lança `EmailAlreadyExists`/`CNPJAlreadyExists`), aplicar hash de senha, persistir via `NGORepository`, mapear para `NGOResponse` com `is_active=True`, sem expor hash
    - _Requisitos: 7.1, 7.2, 7.3, 5.1, 6.1, 6.2_
  - [ ]* 10.4 Escrever testes unitários do NGOService
    - Criar ONG, rejeitar e-mail/CNPJ duplicado (409), garantir hash aplicado e ausência de hash na resposta (mocks de repositório)
    - _Requisitos: 7.1, 7.2, 5.1, 6.1, 6.2_

- [ ] 11. Implementar o AlertService (alerta de localização)
  - [ ] 11.1 Implementar `AlertService.send_location_alert` (`app/services/alert_service.py`)
    - Resolver o destinatário conforme `recipient_type` (usuário via `UserRepository` ou ONG via `NGORepository`) e o pet (404 se inexistente), montar a mensagem, publicar no SNS; persistir o `LocationAlert` com `recipient_type`/`recipient_id` somente após publicação bem-sucedida (não persistir em falha → `NotificationError`)
    - _Requisitos: 3.1, 3.2, 3.3, 3.4, 3.5, 5.2, 5.3, 7.6_
  - [ ]* 11.2 Escrever teste de propriedade de atomicidade do alerta
    - **Property 4 (P4): Atomicidade do alerta** — se a publicação no SNS falhar, nenhum registro é criado em `location_alerts`
    - **Validates: Requisitos 3.5, 5.3**
  - [ ]* 11.3 Escrever teste de propriedade de rastreabilidade do alerta
    - **Property 6 (P6): Rastreabilidade** — todo alerta persistido possui `sns_message_id` não vazio
    - **Validates: Requisitos 2.4, 3.3**
  - [ ]* 11.4 Escrever testes unitários do AlertService
    - Cobrir usuário/pet inexistente (404) e não persistência em falha do SNS (mocks de repositórios e cliente SNS)
    - _Requisitos: 3.1, 5.2, 5.3_

- [ ] 12. Checkpoint - Garantir que todos os testes passam
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 13. Implementar os routers e endpoints da API
  - [ ] 13.1 Implementar o router de usuários (`app/api/routers/users.py`)
    - `POST /api/v1/users` (201 + `UserResponse`) e `GET /api/v1/users/{user_id}` (200), injetando `UserService`
    - _Requisitos: 1.1, 1.3, 1.4_
  - [ ] 13.4 Implementar o router de ONGs (`app/api/routers/ngos.py`)
    - `POST /api/v1/ngos` (201 + `NGOResponse`) e `GET /api/v1/ngos/{ngo_id}` (200), injetando `NGOService`
    - _Requisitos: 7.1, 7.3, 7.4_
  - [ ] 13.2 Implementar o router de alertas (`app/api/routers/alerts.py`)
    - `POST /api/v1/alerts` (202 + `AlertResponse`), injetando `AlertService`
    - _Requisitos: 3.1, 3.3_
  - [ ]* 13.3 Escrever testes de endpoint com TestClient
    - Cobrir 201, 200, 202, 409, 404 e 422 nas rotas
    - _Requisitos: 1.1, 1.4, 3.1, 3.3, 5.1, 5.2, 4.1, 4.6_

- [ ] 14. Fazer o wiring da aplicação (ponto de entrada)
  - [ ] 14.1 Criar `app/main.py` montando o FastAPI
    - Registrar routers (usuários, ONGs, alertas), exception handlers, dependências (sessão de banco, repositórios incl. `NGORepository`, `SNSNotificationClient`, serviços incl. `NGOService`) e a configuração
    - _Requisitos: 1.1, 3.1, 5.5, 6.5, 7.1_
  - [ ]* 14.2 Escrever teste de integração do fluxo completo de registro
    - Registro contra um MySQL de teste (ou equivalente) cobrindo persistência com `is_active=True` e ausência de hash na resposta
    - _Requisitos: 1.1, 1.2, 1.3, 6.2_
  - [ ]* 14.3 Escrever teste de integração do fluxo completo de alerta com moto
    - Publicação no SNS mockada (moto) + persistência em `location_alerts` e resposta 202
    - _Requisitos: 3.1, 3.2, 3.3, 3.4_

- [ ] 15. Checkpoint final - Garantir que todos os testes passam
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tarefas marcadas com `*` são opcionais (testes) e podem ser puladas para um MVP mais rápido.
- Cada tarefa referencia requisitos específicos para rastreabilidade; tarefas de teste de propriedade referenciam P1-P6 do design.
- Os checkpoints garantem validação incremental em pontos naturais de pausa.
- Testes de propriedade (Hypothesis) usam no mínimo 100 iterações e validam as propriedades universais P1-P6.
- Testes unitários cobrem exemplos específicos e condições de erro; testes de integração usam `TestClient` e `moto`.

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["2.1", "3.1", "6.1", "9.1"] },
    { "id": 2, "tasks": ["2.2", "4.1", "5.1", "5.2", "5.6", "6.2", "8.1"] },
    { "id": 3, "tasks": ["4.2", "5.3", "5.4", "5.5", "7.1", "7.2", "7.4", "8.2", "9.2"] },
    { "id": 4, "tasks": ["4.3", "7.3", "9.3", "10.1", "10.3", "11.1"] },
    { "id": 5, "tasks": ["10.2", "10.4", "11.2", "11.3", "11.4", "13.1", "13.2", "13.4"] },
    { "id": 6, "tasks": ["13.3", "14.1"] },
    { "id": 7, "tasks": ["14.2", "14.3"] }
  ]
}
```
