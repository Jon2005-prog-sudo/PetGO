# Requirements Document

> ## Nota de Integracao (ponte spec <-> codigo)
> Este spec descreve o PetGo ideal (FastAPI + MySQL + AWS SNS). O codigo
> entregue segue a **Opcao 3 (ponte)**: mantem o programa real em **Flask +
> armazenamento JSON + interface web** e porta os conceitos deste spec que
> cabem sem trocar o framework ou exigir infraestrutura externa.
>
> | Spec (PetGo ideal) | Codigo entregue (ponte) |
> |--------------------|-------------------------|
> | FastAPI + Pydantic | Flask + validacao manual (`validacao.py`) |
> | MySQL + SQLAlchemy + Alembic | JSON em `data/` (`store.py`) |
> | Hash bcrypt (passlib) | Hash pbkdf2/scrypt (`werkzeug.security`) |
> | AWS SNS via boto3 | Notificador local plugavel (`notificador.py`) |
> | API pura `/api/v1/...` | API `/api/...` **+ telas HTML** |
> | Entidade `Pet` (perdido/resgatado) | Entidade `animal` (aberto/em andamento/resolvido) |
>
> **Portado para o codigo:** registro de usuario e de ONG com senha em hash;
> unicidade de e-mail e de CNPJ; validacao de senha forte, telefone E.164 e
> CNPJ; alerta de localizacao com atomicidade (so grava apos publicar).
> **Nao portado (seria a Opcao 2):** FastAPI, Pydantic, MySQL, SNS real.

## Introduction

Este documento define os requisitos da **API de Registro de Usuário e Alerta de Resgate de Pets do PetGo**, derivados do documento de design aprovado. O PetGo é um aplicativo interativo de resgate de pets cuja API, construída em **Python 3.11+ com FastAPI**, oferece: cadastro de usuários e de **ONGs de adoção** com validação e armazenamento seguro de senha (bcrypt), persistência em **MySQL** via **SQLAlchemy/PyMySQL**, e envio de **alertas de localização do pet** a usuários e ONGs através do **AWS SNS (boto3)**, com histórico persistido.

Os requisitos a seguir cobrem registro, persistência, notificação via SNS, validação de dados, tratamento de erros e segurança como preocupações distintas. As histórias de usuário e os critérios de aceitação estão redigidos em português, enquanto os títulos estruturais seguem a forma canônica em inglês exigida pelo validador de especificações. Os critérios de aceitação seguem o padrão EARS.

## Glossary

- **API_PetGo**: O sistema de backend (serviço REST em FastAPI) que expõe os endpoints de usuário e alerta.
- **Serviço_Registro**: Componente (UserService) responsável por orquestrar o cadastro de usuários.
- **Serviço_Alerta**: Componente (AlertService) responsável por montar, publicar e registrar alertas de localização.
- **Repositório_Dados**: Camada de persistência (UserRepository, PetRepository, AlertRepository) sobre MySQL via SQLAlchemy/PyMySQL.
- **Cliente_SNS**: Componente (SNSNotificationClient) que publica mensagens no tópico AWS SNS via boto3.
- **Banco_MySQL**: A base de dados MySQL com as tabelas `users`, `ngos`, `pets` e `location_alerts`.
- **Usuário**: Pessoa que se cadastra na API e recebe alertas de localização de pets.
- **Hash_Senha**: Valor derivado da senha por meio do algoritmo bcrypt, armazenado no lugar da senha em texto puro.
- **Formato_E164**: Formato internacional de número de telefone (ex.: `+5511999998888`).
- **Alerta_Localização**: Registro (LocationAlert) que representa uma notificação de localização de pet enviada a um destinatário (usuário ou ONG).
- **MessageId_SNS**: Identificador retornado pelo AWS SNS após a publicação bem-sucedida de uma mensagem.
- **ONG_Adoção**: Organização não governamental de adoção de pets que se cadastra na API, autentica e pode receber alertas de localização.
- **Serviço_Registro_ONG**: Componente (NGOService) responsável por orquestrar o cadastro de ONGs de adoção.
- **Formato_CNPJ**: Cadastro Nacional da Pessoa Jurídica brasileiro, composto por 14 dígitos (ex.: `12.345.678/0001-95`).
- **Destinatário_Alerta**: Entidade que recebe um Alerta_Localização; pode ser um Usuário (`user`) ou uma ONG_Adoção (`ngo`).

## Requirements

### Requirement 1: Registro de Usuário

**User Story:** Como uma pessoa usuária do PetGo, quero me cadastrar na plataforma informando meus dados, para que eu possa receber alertas de localização dos pets.

#### Acceptance Criteria

1. WHEN uma requisição `POST /api/v1/users` é recebida com `full_name`, `email`, `phone` e `password` válidos e com e-mail ainda não cadastrado, THE API_PetGo SHALL criar um novo usuário e responder com o código HTTP 201 e um corpo `UserResponse`.
2. WHEN um novo usuário é criado com sucesso, THE Serviço_Registro SHALL persistir o usuário no Banco_MySQL com o campo `is_active` igual a verdadeiro.
3. WHEN um novo usuário é persistido, THE Serviço_Registro SHALL retornar uma resposta contendo `id`, `full_name`, `email`, `phone`, `is_active` e `created_at`.
4. WHEN uma requisição `GET /api/v1/users/{user_id}` é recebida para um usuário existente, THE API_PetGo SHALL responder com o código HTTP 200 e os dados públicos do usuário.

### Requirement 2: Persistência de Dados no MySQL

**User Story:** Como mantenedor do sistema, quero que os dados de usuários, pets e alertas sejam armazenados de forma confiável no MySQL, para que as informações permaneçam íntegras e consultáveis.

#### Acceptance Criteria

1. WHEN o Serviço_Registro solicita a criação de um usuário, THE Repositório_Dados SHALL inserir o registro na tabela `users` do Banco_MySQL e retornar o identificador gerado.
2. THE Banco_MySQL SHALL impor unicidade do campo `email` na tabela `users` por meio de uma restrição de chave única.
3. WHEN o Serviço_Registro verifica a existência de um e-mail, THE Repositório_Dados SHALL consultar a tabela `users` pelo campo `email` e retornar o usuário correspondente ou ausência de registro.
4. WHEN um Alerta_Localização é publicado com sucesso no SNS, THE Repositório_Dados SHALL inserir um registro na tabela `location_alerts` contendo `user_id`, `pet_id`, `latitude`, `longitude`, `message` e `sns_message_id`.
5. THE Banco_MySQL SHALL manter as chaves estrangeiras de `pets.owner_user_id`, `location_alerts.pet_id` e, quando o destinatário for um usuário, `location_alerts.user_id`, referenciando registros existentes nas tabelas relacionadas.
6. WHEN o Serviço_Registro_ONG solicita a criação de uma ONG, THE Repositório_Dados SHALL inserir o registro na tabela `ngos` do Banco_MySQL e retornar o identificador gerado.
7. THE Banco_MySQL SHALL impor unicidade dos campos `email` e `cnpj` na tabela `ngos` por meio de restrições de chave única.

### Requirement 3: Alerta de Localização via AWS SNS

**User Story:** Como pessoa usuária do PetGo, quero receber um alerta quando meu pet for localizado, para que eu possa buscá-lo rapidamente.

#### Acceptance Criteria

1. WHEN uma requisição `POST /api/v1/alerts` é recebida com `recipient_type` (`user` ou `ngo`), `recipient_id` e `pet_id` existentes e coordenadas válidas, THE Serviço_Alerta SHALL montar a mensagem de alerta a partir dos dados do destinatário, do pet e da localização.
2. WHEN a mensagem de alerta é montada, THE Cliente_SNS SHALL publicar a mensagem no tópico AWS SNS configurado e retornar o MessageId_SNS.
3. WHEN a publicação no SNS é concluída com sucesso, THE Serviço_Alerta SHALL persistir o Alerta_Localização no Banco_MySQL (registrando o destinatário via `recipient_type` e `recipient_id`) e responder com o código HTTP 202 e um corpo `AlertResponse` contendo `alert_id`, `sns_message_id` e `sent_at`.
4. THE Serviço_Alerta SHALL registrar o histórico de cada alerta enviado na tabela `location_alerts` para fins de auditoria.
5. IF a publicação no SNS falha, THEN THE Serviço_Alerta SHALL abster-se de persistir qualquer registro em `location_alerts`.

### Requirement 4: Validação de Entrada

**User Story:** Como mantenedor do sistema, quero que os dados recebidos sejam validados rigorosamente, para que apenas informações bem-formadas sejam processadas e persistidas.

#### Acceptance Criteria

1. IF o campo `email` de uma requisição de registro não está em formato de e-mail válido, THEN THE API_PetGo SHALL rejeitar a requisição com o código HTTP 422.
2. IF o campo `password` de uma requisição de registro possui menos de 8 caracteres ou não contém ao menos uma letra e um número, THEN THE API_PetGo SHALL rejeitar a requisição com o código HTTP 422.
3. IF o campo `phone` de uma requisição de registro não está no Formato_E164, THEN THE API_PetGo SHALL rejeitar a requisição com o código HTTP 422.
4. IF o campo `full_name` de uma requisição de registro está vazio ou excede 120 caracteres, THEN THE API_PetGo SHALL rejeitar a requisição com o código HTTP 422.
5. IF o campo `latitude` de uma requisição de alerta está fora do intervalo de -90 a 90 ou o campo `longitude` está fora do intervalo de -180 a 180, THEN THE API_PetGo SHALL rejeitar a requisição com o código HTTP 422.
6. WHEN uma requisição é rejeitada por validação, THE API_PetGo SHALL incluir na resposta os detalhes do erro por campo.
7. IF o campo `cnpj` de uma requisição de registro de ONG não possui 14 dígitos válidos no Formato_CNPJ, THEN THE API_PetGo SHALL rejeitar a requisição com o código HTTP 422.

### Requirement 5: Tratamento de Erros

**User Story:** Como pessoa usuária e como mantenedor, quero que a API responda com códigos de erro claros em situações excepcionais, para que o cliente possa reagir corretamente.

#### Acceptance Criteria

1. IF uma requisição de registro (de usuário ou de ONG) informa um `email` já cadastrado, ou uma requisição de registro de ONG informa um `cnpj` já cadastrado, THEN THE API_PetGo SHALL responder com o código HTTP 409 e uma mensagem indicando o conflito.
2. IF uma requisição de alerta informa um `recipient_id` (usuário ou ONG, conforme `recipient_type`) ou `pet_id` inexistente, THEN THE API_PetGo SHALL responder com o código HTTP 404.
3. IF a publicação da mensagem no AWS SNS falha, THEN THE API_PetGo SHALL responder com o código HTTP 502.
4. IF a conexão com o Banco_MySQL está indisponível durante o processamento de uma requisição, THEN THE API_PetGo SHALL responder com o código HTTP 503.
5. WHEN um erro de infraestrutura (SNS ou Banco_MySQL) ocorre, THE API_PetGo SHALL registrar o erro em log para observabilidade sem interromper o serviço para outras requisições.

### Requirement 6: Segurança de Senhas e Credenciais

**User Story:** Como pessoa usuária, quero que minha senha e meus dados sensíveis sejam protegidos, para que minhas informações não sejam expostas nem comprometidas.

#### Acceptance Criteria

1. WHEN uma senha de usuário ou de ONG é recebida no registro, THE Serviço_Registro ou o Serviço_Registro_ONG SHALL gerar um Hash_Senha com bcrypt e armazenar somente o hash no Banco_MySQL.
2. THE API_PetGo SHALL omitir os campos `password` e `password_hash` de toda resposta retornada ao cliente.
3. THE API_PetGo SHALL omitir senhas e Hash_Senha de todos os registros de log.
4. THE Repositório_Dados SHALL executar todas as operações no Banco_MySQL por meio de consultas parametrizadas.
5. THE Cliente_SNS SHALL obter as credenciais da AWS a partir de variáveis de ambiente ou de IAM role em tempo de execução.
6. WHEN uma senha em texto puro precisa ser verificada contra o Hash_Senha armazenado, THE Serviço_Registro SHALL confirmar a correspondência somente quando a senha corresponde ao hash.

### Requirement 7: Registro de ONG de Adoção

**User Story:** Como uma ONG de adoção de pets, quero me cadastrar na plataforma informando meus dados institucionais, para que eu possa autenticar e receber alertas de localização de pets.

#### Acceptance Criteria

1. WHEN uma requisição `POST /api/v1/ngos` é recebida com `name`, `email`, `phone`, `cnpj`, `password` e endereço válidos, com `email` e `cnpj` ainda não cadastrados, THE API_PetGo SHALL criar uma nova ONG e responder com o código HTTP 201 e um corpo `NGOResponse`.
2. WHEN uma nova ONG é criada com sucesso, THE Serviço_Registro_ONG SHALL persistir a ONG no Banco_MySQL com o campo `is_active` igual a verdadeiro e armazenando somente o Hash_Senha.
3. WHEN uma nova ONG é persistida, THE Serviço_Registro_ONG SHALL retornar uma resposta contendo `id`, `name`, `email`, `phone`, `cnpj`, `street`, `city`, `state`, `zip_code`, `website`, `description`, `is_active` e `created_at`, sem expor `password` nem `password_hash`.
4. WHEN uma requisição `GET /api/v1/ngos/{ngo_id}` é recebida para uma ONG existente, THE API_PetGo SHALL responder com o código HTTP 200 e os dados públicos da ONG.
5. IF o campo `name` de uma requisição de registro de ONG está vazio ou excede 150 caracteres, THEN THE API_PetGo SHALL rejeitar a requisição com o código HTTP 422.
6. WHEN um Alerta_Localização é direcionado a uma ONG existente, THE Serviço_Alerta SHALL resolver a ONG pelo `recipient_id` e incluir seus dados de contato na publicação do SNS.
