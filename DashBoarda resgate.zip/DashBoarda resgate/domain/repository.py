"""Repositorio em memoria para o dominio.

Substitui o PostgreSQL/Prisma do design por armazenamento em memoria, o que
e suficiente para exercitar e TESTAR as regras de negocio e as Correctness
Properties. A camada web pode usar outra implementacao (JSON/SQLite) com a
mesma interface, sem mudar os serviços.

Entidades sao dicts simples; os servicos cuidam das regras.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field


def novo_id() -> str:
    return uuid.uuid4().hex[:8]


@dataclass
class InMemoryRepo:
    usuarios: dict[str, dict] = field(default_factory=dict)
    animais: dict[str, dict] = field(default_factory=dict)
    pedidos: dict[str, dict] = field(default_factory=dict)
    denuncias: dict[str, dict] = field(default_factory=dict)
    aplicacoes: dict[str, dict] = field(default_factory=dict)
    notificacoes: dict[str, dict] = field(default_factory=dict)

    # --- usuarios ---
    def add_usuario(self, u: dict) -> dict:
        self.usuarios[u["id"]] = u
        return u

    def get_usuario(self, uid: str) -> dict | None:
        return self.usuarios.get(uid)

    def all_usuarios(self) -> list[dict]:
        return list(self.usuarios.values())

    def save_usuario(self, u: dict) -> dict:
        self.usuarios[u["id"]] = u
        return u

    # --- animais ---
    def add_animal(self, a: dict) -> dict:
        self.animais[a["id"]] = a
        return a

    def get_animal(self, aid: str) -> dict | None:
        return self.animais.get(aid)

    def all_animais(self) -> list[dict]:
        return list(self.animais.values())

    def save_animal(self, a: dict) -> dict:
        self.animais[a["id"]] = a
        return a

    # --- pedidos de adocao ---
    def add_pedido(self, p: dict) -> dict:
        self.pedidos[p["id"]] = p
        return p

    def get_pedido(self, pid: str) -> dict | None:
        return self.pedidos.get(pid)

    def save_pedido(self, p: dict) -> dict:
        self.pedidos[p["id"]] = p
        return p

    def pedidos_do_animal(self, animal_id: str) -> list[dict]:
        return [p for p in self.pedidos.values() if p["animalId"] == animal_id]

    def pedidos_do_adotante(self, adotante_id: str) -> list[dict]:
        return [p for p in self.pedidos.values() if p["adopterId"] == adotante_id]

    # --- denuncias ---
    def add_denuncia(self, r: dict) -> dict:
        self.denuncias[r["id"]] = r
        return r

    def get_denuncia(self, rid: str) -> dict | None:
        return self.denuncias.get(rid)

    def save_denuncia(self, r: dict) -> dict:
        self.denuncias[r["id"]] = r
        return r

    def all_denuncias(self) -> list[dict]:
        return list(self.denuncias.values())

    # --- aplicacoes de protetor ---
    def add_aplicacao(self, a: dict) -> dict:
        self.aplicacoes[a["id"]] = a
        return a

    def get_aplicacao(self, aid: str) -> dict | None:
        return self.aplicacoes.get(aid)

    def save_aplicacao(self, a: dict) -> dict:
        self.aplicacoes[a["id"]] = a
        return a

    def all_aplicacoes(self) -> list[dict]:
        return list(self.aplicacoes.values())

    # --- notificacoes ---
    def add_notificacao(self, n: dict) -> dict:
        self.notificacoes[n["id"]] = n
        return n

    def save_notificacao(self, n: dict) -> dict:
        self.notificacoes[n["id"]] = n
        return n

    def notificacoes_do_usuario(self, uid: str) -> list[dict]:
        return [n for n in self.notificacoes.values() if n["userId"] == uid]
