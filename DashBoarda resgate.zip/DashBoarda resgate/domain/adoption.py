"""Tarefa 9 do DESING: servico de adocao com maquina de estados.

Cobre:
  - createRequest: so animal AVAILABLE; unicidade de pedido ativo    Req 6.1-6.4
  - cancelRequest + transicoes validas                               Req 6.5-6.7 / P9
  - reviewRequest: aprovacao transacional com auto-rejeicao          Req 7.1-7.8
  - Property 3: no maximo um APPROVED por animal
  - Property 4: aprovacao -> animal ADOPTED (atomico)
  - Property 5: pedido so para animal disponivel
  - Property 6: unicidade de pedido ativo (adotante, animal)
  - Property 10: notificacao ao destinatario correto

Como nao ha banco real, a "transacao" e simulada: as mudancas so sao
aplicadas apos todas as verificacoes passarem (sem estado parcial).
"""

from __future__ import annotations

from .types import Role, AnimalStatus, AdoptionStatus, is_valid_adoption_transition
from .errors import (
    NotAuthorized,
    NotFound,
    ValidationError,
    AnimalNotAvailable,
    DuplicateActiveRequest,
    Conflict,
    InvalidTransition,
    DomainError,
)
from .repository import InMemoryRepo, novo_id

ATIVOS = {AdoptionStatus.SENT, AdoptionStatus.UNDER_REVIEW}


class AdoptionService:
    def __init__(self, repo: InMemoryRepo):
        self.repo = repo

    # --- notificacao (Property 10) ---
    def _notificar(self, user_id: str, tipo: str, payload: dict) -> None:
        self.repo.add_notificacao({
            "id": novo_id(),
            "userId": user_id,
            "type": tipo,
            "payload": payload,
            "read": False,
        })

    def create_request(self, adopter_id: str, animal_id: str,
                       message: str = "") -> dict:
        adotante = self.repo.get_usuario(adopter_id)
        if adotante is None:
            raise NotAuthorized("Adotante inexistente.")
        if adotante.get("suspended"):
            raise NotAuthorized("Adotante suspenso.")

        animal = self.repo.get_animal(animal_id)
        if animal is None:
            raise NotFound("Animal nao encontrado.")
        # Property 5: pedido so para animal AVAILABLE.
        if AnimalStatus(animal["status"]) != AnimalStatus.AVAILABLE:
            raise AnimalNotAvailable("Animal nao esta disponivel para adocao.")

        # Property 6: no maximo um pedido ativo por (adotante, animal).
        for p in self.repo.pedidos_do_animal(animal_id):
            if (p["adopterId"] == adopter_id
                    and AdoptionStatus(p["status"]) in ATIVOS):
                raise DuplicateActiveRequest(
                    "Ja existe um pedido ativo seu para este animal."
                )

        pedido = {
            "id": novo_id(),
            "animalId": animal_id,
            "adopterId": adopter_id,
            "status": AdoptionStatus.SENT,
            "message": message,
            "decisionNote": None,
        }
        self.repo.add_pedido(pedido)
        # Req 6.4: evento ADOPTION_REQUEST_CREATED ao protetor dono.
        if animal.get("protectorId"):
            self._notificar(animal["protectorId"], "ADOPTION_REQUEST_CREATED",
                            {"animalId": animal_id, "requestId": pedido["id"]})
        return pedido

    def cancel_request(self, adopter_id: str, request_id: str) -> dict:
        pedido = self.repo.get_pedido(request_id)
        if pedido is None:
            raise NotFound("Pedido nao encontrado.")
        if pedido["adopterId"] != adopter_id:
            raise NotAuthorized("So o proprio adotante cancela seu pedido.")
        atual = AdoptionStatus(pedido["status"])
        # Property 9: valida transicao -> CANCELLED.
        if not is_valid_adoption_transition(atual, AdoptionStatus.CANCELLED):
            raise InvalidTransition("Pedido nao pode ser cancelado neste estado.")
        pedido["status"] = AdoptionStatus.CANCELLED
        self.repo.save_pedido(pedido)
        return pedido

    def review_request(self, protector_id: str, request_id: str,
                      decision: str, note: str = "") -> dict:
        if decision not in ("APPROVE", "REJECT"):
            raise ValidationError("decision deve ser 'APPROVE' ou 'REJECT'.")

        ator = self.repo.get_usuario(protector_id)
        if ator is None:
            raise NotAuthorized("Ator inexistente.")

        pedido = self.repo.get_pedido(request_id)
        if pedido is None:
            raise NotFound("Pedido nao encontrado.")
        animal = self.repo.get_animal(pedido["animalId"])
        if animal is None:
            raise NotFound("Animal do pedido nao encontrado.")

        # Property 8 / Req 7.1: so o protetor dono ou admin revisa.
        if ator["role"] != Role.ADMIN and animal["protectorId"] != protector_id:
            raise NotAuthorized("Apenas o protetor dono ou admin revisa o pedido.")

        # Req 7.2: pedido precisa estar pendente.
        if AdoptionStatus(pedido["status"]) not in ATIVOS:
            raise InvalidTransition("Pedido nao esta pendente.")

        if decision == "REJECT":
            # Req 7.6: so o pedido alvo vira REJECTED; animal segue AVAILABLE.
            pedido["status"] = AdoptionStatus.REJECTED
            pedido["decisionNote"] = note
            self.repo.save_pedido(pedido)
            self._notificar(pedido["adopterId"], "ADOPTION_DECISION",
                            {"requestId": pedido["id"], "decision": "REJECTED"})
            return pedido

        # decision == APPROVE
        # Req 7.7 / Property 3: concorrencia -> animal deve estar AVAILABLE.
        if AnimalStatus(animal["status"]) != AnimalStatus.AVAILABLE:
            raise Conflict("Animal nao esta mais disponivel (ja adotado?).")

        # "Transacao": aplicar tudo de uma vez (Property 4 - atomicidade).
        pedido["status"] = AdoptionStatus.APPROVED
        pedido["decisionNote"] = note
        self.repo.save_pedido(pedido)

        # Auto-rejeita os demais pedidos ativos do mesmo animal (Property 3).
        for outro in self.repo.pedidos_do_animal(animal["id"]):
            if outro["id"] == pedido["id"]:
                continue
            if AdoptionStatus(outro["status"]) in ATIVOS:
                outro["status"] = AdoptionStatus.REJECTED
                self.repo.save_pedido(outro)
                self._notificar(outro["adopterId"], "ADOPTION_DECISION",
                                {"requestId": outro["id"], "decision": "REJECTED"})

        # Marca o animal como ADOPTED (Property 4).
        animal["status"] = AnimalStatus.ADOPTED
        self.repo.save_animal(animal)

        # Req 7.8: notifica o adotante aprovado.
        self._notificar(pedido["adopterId"], "ADOPTION_DECISION",
                        {"requestId": pedido["id"], "decision": "APPROVED"})
        return pedido

    def list_requests_for_animal(self, animal_id: str) -> list[dict]:
        return self.repo.pedidos_do_animal(animal_id)

    def list_requests_by_adopter(self, adopter_id: str) -> list[dict]:
        return self.repo.pedidos_do_adotante(adopter_id)
