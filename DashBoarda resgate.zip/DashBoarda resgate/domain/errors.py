"""Excecoes de dominio (mapeiam os cenarios de Error Handling do design)."""

from __future__ import annotations


class DomainError(Exception):
    """Base para erros de regra de negocio."""


class NotAuthorized(DomainError):
    """Ator sem o papel/propriedade exigido (403). Property 8."""


class NotFound(DomainError):
    """Recurso inexistente."""


class ValidationError(DomainError):
    """Entrada invalida (descricao vazia, coordenadas fora de faixa, etc.)."""


class InvalidTransition(DomainError):
    """Transicao de status fora da tabela. Properties 2 e 9."""


class AnimalNotAvailable(DomainError):
    """Pedido de adocao para animal que nao esta AVAILABLE. Property 5."""


class DuplicateActiveRequest(DomainError):
    """Ja existe pedido ativo do mesmo adotante para o mesmo animal. Property 6."""


class Conflict(DomainError):
    """Conflito de concorrencia (ex.: 2a aprovacao do mesmo animal)."""
