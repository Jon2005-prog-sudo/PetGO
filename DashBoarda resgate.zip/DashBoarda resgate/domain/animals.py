"""Tarefa 6 do DESING: servico de animais e ciclo de vida.

Cobre:
  - createAnimal (so protetor verificado; description nao vazia)   Req 3.1, 3.2
  - updateAnimal (so dono ou admin)                                Req 3.3, 3.4
  - changeAnimalStatus (transicao valida)                          Req 3.5-3.7 / P2
  - listAvailable (so AVAILABLE + filtros + paginacao)             Req 5.1-5.5 / P1
  - Property 7: AVAILABLE so com protetor verificado
  - Property 8: autorizacao por papel
"""

from __future__ import annotations

from .types import Role, AnimalStatus, is_valid_animal_transition
from .errors import (
    NotAuthorized,
    NotFound,
    ValidationError,
    InvalidTransition,
)
from .repository import InMemoryRepo, novo_id


class AnimalService:
    def __init__(self, repo: InMemoryRepo):
        self.repo = repo

    def _ator(self, actor_id: str) -> dict:
        ator = self.repo.get_usuario(actor_id)
        if ator is None:
            raise NotAuthorized("Ator inexistente.")
        return ator

    def create_animal(self, protector_id: str, dados: dict) -> dict:
        ator = self._ator(protector_id)
        # Property 7 / Property 8: so protetor verificado cria animal.
        if ator["role"] != Role.PROTECTOR:
            raise NotAuthorized("Apenas protetores verificados cadastram animais.")
        if not str(dados.get("description", "")).strip():
            raise ValidationError("A descricao do animal nao pode ser vazia.")

        animal = {
            "id": novo_id(),
            "protectorId": protector_id,
            "name": dados.get("name", ""),
            "species": dados.get("species", ""),
            "breed": dados.get("breed"),
            "size": dados.get("size"),
            "sex": dados.get("sex"),
            "ageMonths": dados.get("ageMonths"),
            "description": str(dados["description"]).strip(),
            "status": AnimalStatus.SHELTERED,  # protetor cadastra ja abrigado
            "locationCity": dados.get("locationCity", ""),
            "photos": list(dados.get("photos", [])),
        }
        return self.repo.add_animal(animal)

    def get_animal(self, animal_id: str) -> dict:
        a = self.repo.get_animal(animal_id)
        if a is None:
            raise NotFound("Animal nao encontrado.")
        return a

    def update_animal(self, actor_id: str, animal_id: str, patch: dict) -> dict:
        ator = self._ator(actor_id)
        animal = self.get_animal(animal_id)
        # Property 8: so o dono ou admin altera.
        if ator["role"] != Role.ADMIN and animal["protectorId"] != actor_id:
            raise NotAuthorized("Apenas o protetor dono ou admin altera o animal.")
        if "description" in patch and not str(patch["description"]).strip():
            raise ValidationError("A descricao do animal nao pode ser vazia.")
        for campo in ("name", "species", "breed", "size", "sex", "ageMonths",
                      "description", "locationCity"):
            if campo in patch:
                animal[campo] = patch[campo]
        self.repo.save_animal(animal)
        return animal

    def change_status(self, actor_id: str, animal_id: str, nxt: AnimalStatus) -> dict:
        ator = self._ator(actor_id)
        animal = self.get_animal(animal_id)
        if ator["role"] != Role.ADMIN and animal["protectorId"] != actor_id:
            raise NotAuthorized("Sem permissao para mudar o status deste animal.")
        atual = AnimalStatus(animal["status"])
        nxt = AnimalStatus(nxt)
        # Property 2: so transicoes validas sao persistidas.
        if not is_valid_animal_transition(atual, nxt):
            raise InvalidTransition(f"Transicao invalida: {atual.value} -> {nxt.value}")
        animal["status"] = nxt
        self.repo.save_animal(animal)
        return animal

    def list_available(self, filtro: dict | None = None, offset: int = 0,
                       limit: int = 20) -> dict:
        filtro = filtro or {}
        if filtro.get("ageMonthsMax") is not None and filtro["ageMonthsMax"] < 0:
            raise ValidationError("ageMonthsMax nao pode ser negativo.")

        # Property 1: so animais AVAILABLE entram na vitrine.
        itens = [a for a in self.repo.all_animais()
                 if AnimalStatus(a["status"]) == AnimalStatus.AVAILABLE]

        if filtro.get("species"):
            itens = [a for a in itens if a.get("species") == filtro["species"]]
        if filtro.get("size"):
            itens = [a for a in itens if a.get("size") == filtro["size"]]
        if filtro.get("sex"):
            itens = [a for a in itens if a.get("sex") == filtro["sex"]]
        if filtro.get("locationCity"):
            itens = [a for a in itens if a.get("locationCity") == filtro["locationCity"]]
        if filtro.get("ageMonthsMax") is not None:
            itens = [a for a in itens
                     if a.get("ageMonths") is not None
                     and a["ageMonths"] <= filtro["ageMonthsMax"]]

        total = len(itens)
        pagina = itens[offset:offset + limit]
        return {"items": pagina, "total": total, "offset": offset, "limit": limit}
