"""Repositorio do dominio que PERSISTE em JSON.

Mesma interface do InMemoryRepo, mas grava em arquivos JSON na pasta data/.
Assim os servicos de dominio (AnimalService, AdoptionService, etc.) rodam
sem alteracao, e os dados sobrevivem entre reinicios da aplicacao.

As entidades sao guardadas com os status como strings (os enums herdam de
str, entao serializam direto; na leitura ficam strings, que os servicos
convertem via AnimalStatus(...)/AdoptionStatus(...)).
"""

from __future__ import annotations

import json
import uuid
from enum import Enum
from pathlib import Path
from threading import Lock

PASTA_DADOS = Path(__file__).resolve().parent.parent / "data"
PASTA_FOTOS = PASTA_DADOS / "photos"


def novo_id() -> str:
    return uuid.uuid4().hex[:8]


def _coerce(valor):
    """Converte enums e aninhados para tipos JSON puros.

    Os enums do dominio herdam de str, mas str(enum) devolve 'Classe.NOME'.
    Por isso extraimos explicitamente o .value (ex.: 'ADMIN', 'AVAILABLE').
    """
    if isinstance(valor, Enum):
        return valor.value
    if isinstance(valor, dict):
        return {k: _coerce(v) for k, v in valor.items()}
    if isinstance(valor, list):
        return [_coerce(v) for v in valor]
    return valor


class JsonRepo:
    """Persistencia JSON com a mesma interface do InMemoryRepo."""

    def __init__(self, pasta: Path | None = None):
        self.pasta = Path(pasta) if pasta else PASTA_DADOS
        self.pasta.mkdir(parents=True, exist_ok=True)
        self._lock = Lock()
        self._arquivos = {
            "usuarios": self.pasta / "d_usuarios.json",
            "animais": self.pasta / "d_animais.json",
            "pedidos": self.pasta / "d_pedidos.json",
            "denuncias": self.pasta / "d_denuncias.json",
            "aplicacoes": self.pasta / "d_aplicacoes.json",
            "notificacoes": self.pasta / "d_notificacoes.json",
        }

    # --- IO interno ---
    def _ler(self, nome: str) -> dict[str, dict]:
        arq = self._arquivos[nome]
        if not arq.exists():
            return {}
        try:
            return json.loads(arq.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {}

    def _escrever(self, nome: str, dados: dict[str, dict]) -> None:
        arq = self._arquivos[nome]
        arq.write_text(
            json.dumps(_coerce(dados), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # --- usuarios ---
    def add_usuario(self, u: dict) -> dict:
        with self._lock:
            d = self._ler("usuarios")
            d[u["id"]] = _coerce(u)
            self._escrever("usuarios", d)
        return u

    def get_usuario(self, uid: str) -> dict | None:
        return self._ler("usuarios").get(uid)

    def all_usuarios(self) -> list[dict]:
        return list(self._ler("usuarios").values())

    def save_usuario(self, u: dict) -> dict:
        return self.add_usuario(u)

    # --- animais ---
    def add_animal(self, a: dict) -> dict:
        with self._lock:
            d = self._ler("animais")
            d[a["id"]] = _coerce(a)
            self._escrever("animais", d)
        return a

    def get_animal(self, aid: str) -> dict | None:
        return self._ler("animais").get(aid)

    def all_animais(self) -> list[dict]:
        return list(self._ler("animais").values())

    def save_animal(self, a: dict) -> dict:
        return self.add_animal(a)

    # --- pedidos ---
    def add_pedido(self, p: dict) -> dict:
        with self._lock:
            d = self._ler("pedidos")
            d[p["id"]] = _coerce(p)
            self._escrever("pedidos", d)
        return p

    def get_pedido(self, pid: str) -> dict | None:
        return self._ler("pedidos").get(pid)

    def save_pedido(self, p: dict) -> dict:
        return self.add_pedido(p)

    def pedidos_do_animal(self, animal_id: str) -> list[dict]:
        return [p for p in self._ler("pedidos").values() if p["animalId"] == animal_id]

    def pedidos_do_adotante(self, adotante_id: str) -> list[dict]:
        return [p for p in self._ler("pedidos").values() if p["adopterId"] == adotante_id]

    # --- denuncias ---
    def add_denuncia(self, r: dict) -> dict:
        with self._lock:
            d = self._ler("denuncias")
            d[r["id"]] = _coerce(r)
            self._escrever("denuncias", d)
        return r

    def get_denuncia(self, rid: str) -> dict | None:
        return self._ler("denuncias").get(rid)

    def save_denuncia(self, r: dict) -> dict:
        return self.add_denuncia(r)

    def all_denuncias(self) -> list[dict]:
        return list(self._ler("denuncias").values())

    # --- aplicacoes de protetor ---
    def add_aplicacao(self, a: dict) -> dict:
        with self._lock:
            d = self._ler("aplicacoes")
            d[a["id"]] = _coerce(a)
            self._escrever("aplicacoes", d)
        return a

    def get_aplicacao(self, aid: str) -> dict | None:
        return self._ler("aplicacoes").get(aid)

    def save_aplicacao(self, a: dict) -> dict:
        return self.add_aplicacao(a)

    def all_aplicacoes(self) -> list[dict]:
        return list(self._ler("aplicacoes").values())

    # --- notificacoes ---
    def add_notificacao(self, n: dict) -> dict:
        with self._lock:
            d = self._ler("notificacoes")
            d[n["id"]] = _coerce(n)
            self._escrever("notificacoes", d)
        return n

    def save_notificacao(self, n: dict) -> dict:
        return self.add_notificacao(n)

    def notificacoes_do_usuario(self, uid: str) -> list[dict]:
        return [n for n in self._ler("notificacoes").values() if n["userId"] == uid]
