"""Tarefa 2 do DESING: enums de dominio, tabelas de transicao e validacao.

Mapeia 1:1 os tipos TypeScript do design:
  Role, AnimalStatus, AdoptionStatus, ReportStatus, ApplicationStatus
  ANIMAL_TRANSITIONS, ADOPTION_TRANSITIONS
  isValidAnimalTransition / isValidAdoptionTransition

Garante as Properties 2 e 9 (transicoes sempre validas; estados terminais
nao transitam).
"""

from __future__ import annotations

from enum import Enum


class Role(str, Enum):
    VISITOR = "VISITOR"
    ADOPTER = "ADOPTER"
    PROTECTOR = "PROTECTOR"
    ADMIN = "ADMIN"


class AnimalStatus(str, Enum):
    NEEDS_RESCUE = "NEEDS_RESCUE"
    IN_RESCUE = "IN_RESCUE"
    SHELTERED = "SHELTERED"
    AVAILABLE = "AVAILABLE"
    ADOPTED = "ADOPTED"
    UNAVAILABLE = "UNAVAILABLE"


class AdoptionStatus(str, Enum):
    SENT = "SENT"
    UNDER_REVIEW = "UNDER_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"


class ReportStatus(str, Enum):
    OPEN = "OPEN"
    ASSUMED = "ASSUMED"
    CLOSED = "CLOSED"


class ApplicationStatus(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


# Tabelas de transicao (identicas as do design).
ANIMAL_TRANSITIONS: dict[AnimalStatus, list[AnimalStatus]] = {
    AnimalStatus.NEEDS_RESCUE: [AnimalStatus.IN_RESCUE],
    AnimalStatus.IN_RESCUE: [AnimalStatus.SHELTERED],
    AnimalStatus.SHELTERED: [AnimalStatus.AVAILABLE, AnimalStatus.UNAVAILABLE],
    AnimalStatus.AVAILABLE: [AnimalStatus.ADOPTED, AnimalStatus.UNAVAILABLE],
    AnimalStatus.UNAVAILABLE: [AnimalStatus.AVAILABLE],
    AnimalStatus.ADOPTED: [],
}

ADOPTION_TRANSITIONS: dict[AdoptionStatus, list[AdoptionStatus]] = {
    AdoptionStatus.SENT: [
        AdoptionStatus.UNDER_REVIEW,
        AdoptionStatus.CANCELLED,
        AdoptionStatus.REJECTED,
    ],
    AdoptionStatus.UNDER_REVIEW: [
        AdoptionStatus.APPROVED,
        AdoptionStatus.REJECTED,
        AdoptionStatus.CANCELLED,
    ],
    AdoptionStatus.APPROVED: [],
    AdoptionStatus.REJECTED: [],
    AdoptionStatus.CANCELLED: [],
}


def is_valid_animal_transition(current: AnimalStatus, nxt: AnimalStatus) -> bool:
    """Property 2: so transicoes da tabela sao validas."""
    return nxt in ANIMAL_TRANSITIONS.get(current, [])


def is_valid_adoption_transition(current: AdoptionStatus, nxt: AdoptionStatus) -> bool:
    """Property 9: transicoes validas; estados terminais nao transitam."""
    return nxt in ADOPTION_TRANSITIONS.get(current, [])
