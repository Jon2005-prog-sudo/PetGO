"""Tarefa 5 do DESING: usuarios e verificacao de protetor.

  - register: cria usuario com papel inicial ADOPTER (email unico)
  - request_protector_verification: cria ProtectorApplication PENDING
  - decide_protector_verification: ADMIN aprova (promove a PROTECTOR) ou rejeita
  - notifica o solicitante do resultado
"""

from __future__ import annotations

from .types import Role, ApplicationStatus
from .errors import NotAuthorized, NotFound, ValidationError
from .repository import novo_id


class UserService:
    def __init__(self, repo):
        self.repo = repo

    def register(self, nome: str, email: str, senha_hash: str,
                 role: Role = Role.ADOPTER) -> dict:
        email = (email or "").strip().lower()
        if not email:
            raise ValidationError("E-mail obrigatorio.")
        if any(u["email"] == email for u in self.repo.all_usuarios()):
            raise ValidationError("Ja existe um usuario com este e-mail.")
        usuario = {
            "id": novo_id(),
            "name": nome.strip(),
            "email": email,
            "passwordHash": senha_hash,
            "role": role,
            "suspended": False,
        }
        return self.repo.add_usuario(usuario)

    def request_protector_verification(self, user_id: str, org_name: str,
                                       document_url: str = "") -> dict:
        u = self.repo.get_usuario(user_id)
        if u is None:
            raise NotFound("Usuario nao encontrado.")
        app = {
            "id": novo_id(),
            "userId": user_id,
            "orgName": org_name.strip(),
            "documentUrl": document_url,
            "status": ApplicationStatus.PENDING,
            "reason": None,
        }
        self.repo.add_aplicacao(app)
        return app

    def list_pending_applications(self) -> list[dict]:
        return [a for a in self.repo.all_aplicacoes()
                if ApplicationStatus(a["status"]) == ApplicationStatus.PENDING]

    def decide_protector_verification(self, admin_id: str, user_id: str,
                                      decision: str, reason: str = "") -> dict:
        admin = self.repo.get_usuario(admin_id)
        if admin is None or admin["role"] != Role.ADMIN:
            raise NotAuthorized("Apenas administradores decidem verificacoes.")
        u = self.repo.get_usuario(user_id)
        if u is None:
            raise NotFound("Usuario solicitante nao encontrado.")
        if decision == "APPROVE":
            u["role"] = Role.PROTECTOR
            self.repo.save_usuario(u)
            self._notificar(user_id, "VERIFICATION_RESULT", {"result": "APPROVED"})
        elif decision == "REJECT":
            self._notificar(user_id, "VERIFICATION_RESULT",
                            {"result": "REJECTED", "reason": reason})
        else:
            raise ValidationError("decision deve ser 'APPROVE' ou 'REJECT'.")
        return u

    def _notificar(self, user_id: str, tipo: str, payload: dict) -> None:
        self.repo.add_notificacao({
            "id": novo_id(),
            "userId": user_id,
            "type": tipo,
            "payload": payload,
            "read": False,
        })
