"""Tarefa 8 do DESING: denuncias e resgate.

  - report_animal: cria RescueReport OPEN (valida coordenadas e descricao)
  - list_open_reports: so denuncias OPEN
  - assume_rescue: protetor assume -> cria animal IN_RESCUE, denuncia ASSUMED
"""

from __future__ import annotations

from .types import Role, AnimalStatus, ReportStatus
from .errors import NotAuthorized, NotFound, ValidationError
from .repository import novo_id


class RescueService:
    def __init__(self, repo):
        self.repo = repo

    def report_animal(self, reporter_id: str, dados: dict) -> dict:
        descricao = str(dados.get("description", "")).strip()
        if not descricao:
            raise ValidationError("A descricao da denuncia nao pode ser vazia.")
        try:
            lat = float(dados["latitude"])
            lon = float(dados["longitude"])
        except (KeyError, TypeError, ValueError):
            raise ValidationError("Coordenadas invalidas.")
        if not (-90.0 <= lat <= 90.0) or not (-180.0 <= lon <= 180.0):
            raise ValidationError("Coordenadas fora do intervalo valido.")

        denuncia = {
            "id": novo_id(),
            "reporterId": reporter_id,
            "description": descricao,
            "latitude": lat,
            "longitude": lon,
            "locationCity": dados.get("locationCity", ""),
            "photos": list(dados.get("photos", [])),
            "status": ReportStatus.OPEN,
        }
        return self.repo.add_denuncia(denuncia)

    def list_open_reports(self) -> list[dict]:
        return [r for r in self.repo.all_denuncias()
                if ReportStatus(r["status"]) == ReportStatus.OPEN]

    def assume_rescue(self, protector_id: str, report_id: str) -> dict:
        ator = self.repo.get_usuario(protector_id)
        if ator is None or ator["role"] != Role.PROTECTOR:
            raise NotAuthorized("Apenas protetores verificados assumem resgates.")
        denuncia = self.repo.get_denuncia(report_id)
        if denuncia is None:
            raise NotFound("Denuncia nao encontrada.")
        if ReportStatus(denuncia["status"]) != ReportStatus.OPEN:
            raise ValidationError("Denuncia nao esta aberta.")

        # Cria o animal vinculado, ja em resgate.
        animal = {
            "id": novo_id(),
            "protectorId": protector_id,
            "name": denuncia.get("description", "")[:40] or "Resgatado",
            "species": "",
            "breed": None, "size": None, "sex": None, "ageMonths": None,
            "description": denuncia["description"],
            "status": AnimalStatus.IN_RESCUE,
            "locationCity": denuncia.get("locationCity", ""),
            "photos": list(denuncia.get("photos", [])),
            "reportId": report_id,
        }
        self.repo.add_animal(animal)

        denuncia["status"] = ReportStatus.ASSUMED
        denuncia["animalId"] = animal["id"]
        self.repo.save_denuncia(denuncia)
        return animal
