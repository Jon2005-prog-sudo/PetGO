"""Dominio do animal-rescue-app (implementacao Python do design em DESING/).

Porta a logica de dominio do design (NestJS/TS) para Python puro, mantendo
as 10 Correctness Properties. Sem framework web/banco aqui: so regras de
negocio testaveis. A camada web (app.py) pode consumir este dominio.
"""

from .types import (
    Role,
    AnimalStatus,
    AdoptionStatus,
    ReportStatus,
    ApplicationStatus,
    ANIMAL_TRANSITIONS,
    ADOPTION_TRANSITIONS,
    is_valid_animal_transition,
    is_valid_adoption_transition,
)

__all__ = [
    "Role",
    "AnimalStatus",
    "AdoptionStatus",
    "ReportStatus",
    "ApplicationStatus",
    "ANIMAL_TRANSITIONS",
    "ADOPTION_TRANSITIONS",
    "is_valid_animal_transition",
    "is_valid_adoption_transition",
]
