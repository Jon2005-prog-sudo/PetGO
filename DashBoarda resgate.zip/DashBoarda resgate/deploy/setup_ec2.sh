#!/usr/bin/env bash
# Provisiona a aplicacao web de resgate (Flask + Apache) num EC2.
# Suporta Amazon Linux 2023 (dnf/httpd) e Ubuntu (apt/apache2).
#
# Rode DENTRO do EC2 (via SSH), a partir de /opt/rescue-app depois de
# copiar os arquivos do projeto para la:
#
#   sudo bash deploy/setup_ec2.sh
#
set -euo pipefail

APP_DIR="/opt/rescue-app"
cd "$APP_DIR"

# Detecta a familia da distro.
if command -v dnf >/dev/null 2>&1; then
  DISTRO="amazon"
else
  DISTRO="ubuntu"
fi

echo ">> [1/5] Instalando Python, pip e Apache..."
if [ "$DISTRO" = "amazon" ]; then
  sudo dnf install -y python3 python3-pip httpd
  APACHE_SVC="httpd"
  APACHE_CONF="/etc/httpd/conf.d/rescue.conf"
else
  sudo apt-get update -y
  sudo apt-get install -y python3 python3-pip python3-venv apache2
  sudo a2enmod proxy proxy_http headers
  APACHE_SVC="apache2"
  APACHE_CONF="/etc/apache2/sites-available/rescue.conf"
fi

echo ">> [2/5] Criando virtualenv e instalando dependencias..."
python3 -m venv venv
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt

echo ">> [3/5] Instalando o servico systemd (gunicorn -> app:app)..."
sudo cp deploy/rescue-app.service /etc/systemd/system/rescue-app.service
sudo systemctl daemon-reload
sudo systemctl enable --now rescue-app

echo ">> [4/5] Configurando o Apache como proxy reverso..."
sudo cp deploy/apache-rescue.conf "$APACHE_CONF"
if [ "$DISTRO" = "ubuntu" ]; then
  sudo a2ensite rescue
  sudo a2dissite 000-default || true
fi
sudo systemctl enable --now "$APACHE_SVC"
sudo systemctl restart "$APACHE_SVC"

echo ">> [5/5] Pronto. Status dos servicos:"
sudo systemctl --no-pager status rescue-app || true
sudo systemctl --no-pager status "$APACHE_SVC" || true
echo
echo ">> Teste local:  curl http://localhost/api/health"
echo ">> Teste externo: curl http://SEU_IP_PUBLICO/api/health"
