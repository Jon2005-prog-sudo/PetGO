# Deploy da Aplicação Web de Resgate no EC2

Guia para subir a aplicação (Flask + Apache como proxy reverso) numa
instância EC2 e deixá-la acessível na porta 80.

> **Custos:** EC2 cobra por hora ligada + tráfego. Uma `t3.micro`/`t2.micro`
> pode caber no free tier. **Desligue a instância** quando não estiver usando.

## Visão geral da arquitetura

```
Internet ──▶ Apache (porta 80)  ──proxy──▶  gunicorn (127.0.0.1:8000)  ──▶  Flask (app:app)
```

O gunicorn roda só em localhost; o Apache é a porta de entrada pública.

## 1. Criar a instância EC2

No console AWS (EC2 → Launch instance):

1. **AMI:** Amazon Linux 2023 (o script também suporta Ubuntu).
2. **Tipo:** `t3.micro` (ou `t2.micro` no free tier).
3. **Key pair:** crie/baixe um `.pem` para acessar por SSH.
4. **Security group** — libere as portas de entrada:
   - `22` (SSH) — de preferência só do seu IP.
   - `80` (HTTP) — de onde as pessoas vão acessar o site/API.
     Para um trabalho, pode liberar `0.0.0.0/0`; o ideal é restringir ao IP do grupo.
   - **Não é preciso abrir a 8000** — o gunicorn fica interno; o Apache fala com ele.

Anote o **IP público** da instância.

## 2. Copiar os arquivos para o EC2

No seu PC (PowerShell), a partir da pasta do projeto. Troque `SEU_IP` e o caminho do `.pem`:

```powershell
# cria a pasta no servidor
ssh -i "C:\caminho\chave.pem" ec2-user@SEU_IP "sudo mkdir -p /opt/rescue-app && sudo chown ec2-user /opt/rescue-app"

# copia os arquivos da aplicacao
scp -i "C:\caminho\chave.pem" app.py store.py validacao.py notificador.py requirements.txt ec2-user@SEU_IP:/opt/rescue-app/
scp -i "C:\caminho\chave.pem" -r templates static domain deploy ec2-user@SEU_IP:/opt/rescue-app/
```

> Se a AMI for Ubuntu, troque `ec2-user` por `ubuntu` (aqui e no `.service`).

## 3. Provisionar (dentro do EC2)

```bash
ssh -i "C:\caminho\chave.pem" ec2-user@SEU_IP
cd /opt/rescue-app
sudo bash deploy/setup_ec2.sh
```

O script instala Python, Apache e dependências, cria o virtualenv, sobe o
gunicorn como serviço `systemd` (reinicia sozinho) e configura o Apache como
proxy reverso na porta 80.

### IMPORTANTE: troque a SECRET_KEY

Antes (ou logo após) o provisionamento, edite
`/etc/systemd/system/rescue-app.service` e troque:

```
Environment=SECRET_KEY=troque-por-uma-chave-aleatoria-longa
```

por uma chave aleatória longa (ex.: saída de `openssl rand -hex 32`). Depois:

```bash
sudo systemctl daemon-reload && sudo systemctl restart rescue-app
```

Sem isso, as sessões de login ficam inseguras.

## 4. Testar

Dentro do EC2:
```bash
curl http://localhost/api/health      # deve responder {"status":"ok"}
```

Do seu PC (ou navegador):
```
http://SEU_IP/            # a aplicacao web
http://SEU_IP/api/health  # a API
```

## 5. Atualizar o código depois

```powershell
scp -i "C:\caminho\chave.pem" app.py ec2-user@SEU_IP:/opt/rescue-app/
```
```bash
sudo systemctl restart rescue-app
```

## Comandos úteis do serviço

```bash
sudo systemctl status rescue-app      # estado do app
sudo journalctl -u rescue-app -f      # logs do app ao vivo
sudo systemctl restart rescue-app     # reiniciar apos atualizar codigo
sudo systemctl status httpd           # Apache (Amazon Linux)  / apache2 no Ubuntu
```

## Observações importantes (honestas)

- **Dados em JSON + disco local:** usuários, ONGs, animais e fotos ficam em
  `/opt/rescue-app/data/`. Se a instância for **recriada**, esses dados se
  perdem. Para o trabalho, resolve; para durar, troque por um banco (RDS) e S3.
- **Concorrência do JSON:** com `--workers 2`, dois processos podem escrever o
  JSON ao mesmo tempo. Pouco provável travar num trabalho, mas é um risco real.
  Se quiser segurança, use 1 worker (`--workers 1`) ou migre para SQLite.
- **HTTP sem TLS:** sobe em HTTP puro. Para HTTPS de verdade, adicione um
  certificado (ex.: Let's Encrypt via `certbot`) no Apache.
- **O domínio do DESING (`domain/`)** vai junto no deploy, mas ainda **não está
  plugado** nas telas; é lógica testada aguardando integração com o `app.py`.
